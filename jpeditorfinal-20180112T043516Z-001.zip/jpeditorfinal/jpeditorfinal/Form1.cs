﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;


using WindowsFormsApplication1.ServiceReference1;

namespace WindowsFormsApplication1
{
    public partial class JPEditor : Form
    {
        public JPEditor()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void connect_Click(object sender, EventArgs e)
        {
            try
            {
               
                OpenFileDialog dlg = new OpenFileDialog();
                dlg.ShowDialog();
                string fileName = "";
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    fileName = dlg.FileName;
                }
                string text = System.IO.File.ReadAllText(fileName);
                java.Text = text;
                String searchString = "\\";
                int startIndex = fileName.LastIndexOf(searchString);
                searchString = "\\" + searchString.Substring(1);
                int endIndex = fileName.IndexOf(searchString);
                String onlyFileName = fileName.Substring(startIndex + 1, fileName.LastIndexOf(".") - fileName.LastIndexOf("\\") - 1);
                string finalStringToService = onlyFileName + "#" + text;
                //java.Text = finalStringToService;
                output.Text = "before";
                FinalReference.jpeClient cl = new FinalReference.jpeClient();
                string output1 = cl.hello(finalStringToService);

                output.Text = output1;
                
                }
            catch (Exception ee)
            {
                MessageBox.Show("erorr");
            }


        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            FinalReference.jpeClient client = new FinalReference.jpeClient();
            string sss = java.Text;
            string output1 = client.hello(sss);
            output.Text = output1;
        }
    }
}
